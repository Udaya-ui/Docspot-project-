declare function hasNativeSymbols(): boolean;

export = hasNativeSymbols;