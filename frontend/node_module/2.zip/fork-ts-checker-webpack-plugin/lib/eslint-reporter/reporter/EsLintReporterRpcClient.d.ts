import { EsLintReporterConfiguration } from '../EsLintReporterConfiguration';
import { ReporterRpcClient } from '../../reporter';
declare function createEsLintReporterRpcClient(configuration: EsLintReporterConfiguration): ReporterRpcClient;
export { createEsLintReporterRpcClient };
