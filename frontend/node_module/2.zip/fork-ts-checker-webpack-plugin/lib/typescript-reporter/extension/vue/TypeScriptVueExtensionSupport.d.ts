import { TypeScriptVueExtensionConfiguration } from './TypeScriptVueExtensionConfiguration';
declare function assertTypeScriptVueExtensionSupport(configuration: TypeScriptVueExtensionConfiguration): void;
export { assertTypeScriptVueExtensionSupport };
