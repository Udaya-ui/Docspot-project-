declare module 'ajv-keywords' {
  import { Ajv } from 'ajv';

  function keywords(ajv: Ajv, include?: string | string[]): Ajv;

  export = keywords;
}
