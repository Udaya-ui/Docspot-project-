declare function _exports(): import('postcss-value-parser').SpaceNode;
export = _exports;
