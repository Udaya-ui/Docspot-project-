require('./').polyfill()
