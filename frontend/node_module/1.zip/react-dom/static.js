'use strict';

module.exports = require('./static.node');
