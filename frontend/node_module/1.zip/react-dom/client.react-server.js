'use strict';

throw new Error(
  'react-dom/client is not supported in React Server Components.'
);
