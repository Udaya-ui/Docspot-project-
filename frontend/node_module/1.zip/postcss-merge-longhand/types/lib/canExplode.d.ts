declare const _exports: (prop: import('postcss').Declaration, includeCustomProps?: boolean) => boolean;
export = _exports;
