declare function _exports(node: import('postcss').Node): import('postcss').Node;
export = _exports;
