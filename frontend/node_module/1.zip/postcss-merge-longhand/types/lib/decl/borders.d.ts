/**
 * @param {import('postcss').Rule} rule
 * @return {void}
 */
export function explode(rule: import('postcss').Rule): void;
/**
 * @param {import('postcss').Rule} rule
 * @return {void}
 */
export function merge(rule: import('postcss').Rule): void;
