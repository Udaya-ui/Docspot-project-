var assertClassBrand = require("./assertClassBrand.js");
function _classPrivateGetter(s, r, a) {
  return a(assertClassBrand(s, r));
}
module.exports = _classPrivateGetter, module.exports.__esModule = true, module.exports["default"] = module.exports;